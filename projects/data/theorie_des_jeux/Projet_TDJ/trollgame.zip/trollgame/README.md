# Etude de stratégies pour le jeux du troll

BONNAVAUD Hedwin,
GUILLARD Tristan

Enseignant : GAVIN Gerald

## Description

Le jeux du troll oppose deux joueurs, qui vont à chaque tour choisir un nombre 
de pierres à lancer vers un troll se trouvant sur une grille, entre les positions
des deux joueurs. A chaque tour, le troll se déplace vers le chateau du joueur qui
a lancé le moins de pierres. Si le troll atteint un chateau, le joueur possédant 
ce chateau a perdu. Pour des règles plus détaillé, voir le document 
jeu_Troll_Chateaux.pdf .

Notre but est de trouver des stratégies, dont la stratégie prudente pour jouer
à ce jeux, et d'en comparer l'efficacité en les faisat s'affronter dans un
tournois. 

## Utilisation
Le code du tp_noté se lance avec ```python3 tp_note.py```
Pour lancer le tournois, exécuter la commande ```python3 tournament.py```.

Pour lancer une vue au coix, modifiez le fichier main.py en initialisant la vue
désirée, puis lancer avec ```python3 main.py```

Pour savoir comment créer une vue ou une stratégie, voir la partie Choix > Modélisation.

## Choix

 #### Modélisation
 
 Notre projet utilise un MVC.
 Il est possible de créer une nouvelle vue en créant une classe fille de 
 AbstractVue. Pour cela, il est important de lire le contenus de la classe 
 et de noter qu'une vue prend en paramètre deux stratégies pour les deux joueurs,
 et s'occupe d'intrancier un controlleur et un modèle.
 
 Pour créer une nouvelle stratégie, il suffit de créer une instance de la classe Strategy.
 
 #### Stratégies
 
 Nous avons choisis d'implémenter les stratégies :
  - Prudente, qui maximise l'espérence de gain du pire cas
  - Donnant-Donnant, qui lance une pierre au premier coup puis ce qu'a joué son
  adverssaire au coup d'avant
  - Constante(i), qui à chaque tour se contente de lancer i pierres
  - Exponentielle(l), qui choisis un nombre de pierres aléatoires selon un loi
  Exponentielle de paramètre lambda (1 par défaut). C'est à dire qu'elle joue 
  de manière aléatoire, avec un forte préférence pour les valeurs faibles.
 
 ## Résultats
 
 Nous avons fait s'affronter ces stratégies dans un tournois, et voici le 
 résultat :
 
 ```
 ================================================================
   ===      Welcome to the bit troll game tournament      ===   
================================================================
Tournament initialisation ...
Take a look at these rules : 
  - Games per match:  10000


 And here are our candidates !! 
  -  Prudent strategy 
  -  Exponential strategy with lambda 1.0
  -  Exponential strategy with lambda 1.5
  -  Tit for tat strategy 
  -  Constant strategy with value 2
  -  Constant strategy with value 5


Tournament is done ! Here are the results:
  - Players 1 candidates : 
      -  1 :  Prudent strategy 
      -  2 :  Exponential strategy with lambda 1.0
      -  3 :  Exponential strategy with lambda 1.5
      -  4 :  Tit for tat strategy 
      -  5 :  Constant strategy with value 2
      -  6 :  Constant strategy with value 5
  - Players 2 candidates : 
      -  1 :  Prudent strategy 
      -  2 :  Exponential strategy with lambda 1.0
      -  3 :  Exponential strategy with lambda 1.5
      -  4 :  Tit for tat strategy 
      -  5 :  Constant strategy with value 2
      -  6 :  Constant strategy with value 5

 In this matrix you can find player 1 gain value.

 Players 1 id are in the left column, and player 2 id are in the first line
          [' 1  ', ' 2  ', ' 3  ', ' 4  ', ' 5  ', ' 6  ']
         _____________________________________________________
  -  1 :  ['0.0', '0.3', '0.5', '0.5', '-0.0', '0.1']
  -  2 :  ['-0.3', '-0.0', '0.0', '-0.0', '-0.9', '-0.9']
  -  3 :  ['-0.5', '-0.0', '-0.0', '-0.1', '-0.8', '-0.6']
  -  4 :  ['-0.5', '0.0', '0.1', '0.0', '0.0', '0.0']
  -  5 :  ['-0.0', '0.9', '0.8', '0.0', '0.0', '-1.0']
  -  6 :  ['-0.1', '0.9', '0.6', '-0.0', '1.0', '0.0']
```