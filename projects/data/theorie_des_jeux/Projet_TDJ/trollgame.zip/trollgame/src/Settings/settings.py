""" Games parameters """
rocks_per_players = 20
grid_size = 7
assert grid_size % 2 == 1 and grid_size >= 5
