from src.Model.ObjectClasses.game_evolution import GameEvolution
from src.View.AbstractView import AbstractView
from src.Model.ObjectClasses.Strategie.abstract_strategy import Strategy


class SingleMatchView(AbstractView):
    """
    This view has been created by Tristan, it make thousands games between two A.I. and print statistics
    about these games.
    """
    def __init__(self, player1_strategy, player2_strategy, nbr_of_games, full_display=False):
        assert(isinstance(player1_strategy, Strategy))
        assert(isinstance(player2_strategy, Strategy))
        print("Loading prudent strategy gains ... ")
        super().__init__(player_1_strategy=player1_strategy,
                         player_2_strategy=player2_strategy)

        self.do_print = full_display
        self.j1won = 0
        self.j2won = 0
        self.draws = 0
        self.nbr_of_games = nbr_of_games
        print("Computing ", self.nbr_of_games, " games")

        for game in range(self.nbr_of_games):
            # Playing a game ...
            if self.do_print:
                print("game")
            self.controller.run()
            self.restart()  # Get a new Model and a new controller for a new game !

        print("Player1 won ", round(self.j1won / self.nbr_of_games * 100, 2), "% of the games", sep='')
        print("Player2 won ", round(self.j2won / self.nbr_of_games * 100, 2), "% of the games", sep='')
        print("There were ", round(self.draws / self.nbr_of_games * 100, 2), "% of draws", sep='')
        if self.j2won > self.j1won:
            print("Player2 won", self.j2won - self.j1won, "more games than Player1")
        elif self.j1won > self.j2won:
            print("Player1 won", self.j1won - self.j2won, "more games than Player2")
        else:
            print("perfect draw")
        return

    def on_turn_end(self):
        if self.do_print:
            print(self.model.current_status())

    def on_game_end(self):
        if self.do_print:
            print("A game ends: ", self.model.game_evolution)
        if self.model.game_evolution == GameEvolution.PLAYER_1_WIN:
            self.j1won += 1
        elif self.model.game_evolution == GameEvolution.PLAYER_2_WIN:
            self.j2won += 1
        elif self.model.game_evolution == GameEvolution.DRAW:
            self.draws += 1
        else:
            raise Exception("unknown result")
