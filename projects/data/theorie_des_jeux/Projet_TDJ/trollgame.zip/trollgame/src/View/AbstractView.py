import abc
from src.Controller.Controller import Controller
from src.Model.Model import Model
from src.Model.ObjectClasses.Strategie.prudent_strategy import Strategy


class AbstractView(abc.ABC):
    def __init__(self, player_1_strategy, player_2_strategy):
        assert player_1_strategy is None or isinstance(player_1_strategy, Strategy)
        assert player_2_strategy is None or isinstance(player_2_strategy, Strategy)
        # Initialise MVC
        self.player_1_strategy = player_1_strategy
        self.player_2_strategy = player_2_strategy
        self.model = None
        self.controller = None
        self.restart()

    def restart(self):
        del self.model
        del self.controller
        self.model = Model(self, player_1_strategy=self.player_1_strategy, player_2_strategy=self.player_2_strategy)
        self.controller = Controller(self.model)

    def update(self):
        """ Called when the model send us a turn end notification """
        if self.model.is_finished():
            self.on_game_end()
        else:
            self.on_turn_end()

    @abc.abstractmethod
    def on_turn_end(self):
        pass

    @abc.abstractmethod
    def on_game_end(self):
        pass

    def get_user_choice(self):
        """
        Ask to the user to select a value between 1 and rocks per player
        :return: Value selected by the user.
        Should be override to be useful
        """
        raise Exception("The player can't play with this view")
