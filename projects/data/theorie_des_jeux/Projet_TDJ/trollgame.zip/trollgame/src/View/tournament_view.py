from time import sleep

from src.Model.ObjectClasses.game_evolution import GameEvolution
from src.View.AbstractView import AbstractView
from src.Model.ObjectClasses.Strategie.prudent_strategy import PrudentStrategy


class TournamentMatchBuilder(AbstractView):

    def __init__(self, strategy_1, strategy_2, games_per_match=10000):
        assert isinstance(games_per_match, int)
        super().__init__(player_1_strategy=strategy_1, player_2_strategy=strategy_2)
        self.player_1_won = 0
        self.player_2_won = 0
        self.games_per_match = games_per_match
        self.draws = 0
        for game in range(games_per_match):
            self.controller.run()
            self.restart()

    def get_result(self):
        player_1_gain = 0.
        player_1_gain += self.player_1_won / self.games_per_match
        player_1_gain -= self.player_2_won / self.games_per_match
        return str(round(player_1_gain, 1))

    def on_turn_end(self):
        pass

    def on_game_end(self):
        if self.model.game_evolution == GameEvolution.PLAYER_1_WIN:
            self.player_1_won += 1
        elif self.model.game_evolution == GameEvolution.PLAYER_2_WIN:
            self.player_2_won += 1
        elif self.model.game_evolution == GameEvolution.DRAW:
            self.draws += 1
        else:
            raise Exception("unknown result")

