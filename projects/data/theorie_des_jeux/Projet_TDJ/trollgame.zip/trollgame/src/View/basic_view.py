from src.Model.ObjectClasses.game_evolution import GameEvolution
from src.View.AbstractView import AbstractView
from src.Model.ObjectClasses.Strategie.prudent_strategy import PrudentStrategy


class BasicView(AbstractView):

    def __init__(self):
        super().__init__(player_1_strategy=PrudentStrategy(player=1),
                         player_2_strategy=PrudentStrategy(player=2))

        print("starting game ...")
        self.controller.run()

    def on_turn_end(self):
        print("Turn ends :")
        print("player 1 choose: ", self.model.player_1_choose)
        print("player 2 choose: ", self.model.player_2_choose)

    def on_game_end(self):
        print("Result: ", self.model.game_evolution)

