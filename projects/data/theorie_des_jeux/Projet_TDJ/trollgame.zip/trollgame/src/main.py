from src.View.single_match_view import SingleMatchView
from src.Model.ObjectClasses.Strategie.prudent_strategy import PrudentStrategy
from src.Model.ObjectClasses.Strategie.constant_strategy import ConstantStrategy


def main():
    # Initialise view:
    SingleMatchView(player1_strategy=PrudentStrategy(player=1),
                    player2_strategy=ConstantStrategy(player=2, value=2),
                    nbr_of_games=10000)


main()
