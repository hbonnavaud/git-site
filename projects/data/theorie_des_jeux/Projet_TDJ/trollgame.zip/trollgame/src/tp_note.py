from src.Model.ObjectClasses.Strategie.Question4.q_4_prud_strat import Question4PrudentStrategy
from src.Model.ObjectClasses.Strategie.Question4.q_4_1_prud_strat import Question41PrudentStrategy
from src.Model.ObjectClasses.Strategie.Question4.q_4_2_prud_strat import Question42PrudentStrategy
from src.Model.ObjectClasses.Strategie.Question4.q_4_3_prud_strat import Question43PrudentStrategy
from src.Model.ObjectClasses.Strategie.Question4.q_3_prud_strat import Question3PrudentStrategy
from src.Model.ObjectClasses.status import Status
from src.Settings.settings import *


prudent_strategy = Question4PrudentStrategy(player=1, rock_per_player=23)

# QUESTION 1
print("\n\nQuestion1_1")
rocks_p1 = 23
rocks_p2 = 20
pos_troll = 2   # t = -1
status_Q1_1 = Status(rocks_p1, rocks_p2, pos_troll)
print("Stratégie du joueur 1 pour l'état (", rocks_p1, ",", rocks_p2, ",", pos_troll, ") = ",
      prudent_strategy.get_gain_or_variables_values(status_Q1_1))

# QUESTION 1 _ 2
print("\n\nQuestion1_2")
rocks_p1 = 20
for rocks_p2 in range(0, 20):
    status_Q1_2 = Status(rocks_p1, rocks_p2, pos_troll)
    if prudent_strategy.get_float_gain(status_Q1_2) < 0:
        print("Gain du joueur 1 pour l'état (", rocks_p1, ",", rocks_p2, ",", pos_troll, ") = ",
              prudent_strategy.get_float_gain(status_Q1_2))
        break


# QUESTION 3

''' Le joueur 1 sait que le joueur 2 ne lance que 1/3 de ses pierres au maximum '''
print("====================================================================================")
print("    Le joueur 1 sait que le joueur 2 ne lance que 1/3 de ses pierres au maximum     ")
print("    fichier Question4/q_3_prud_strat.py            ")
print("=====================================================================================")
print("Initialisation de la stratégie prudente et de ses gains ...")
prudent_strategy = Question3PrudentStrategy(player=1, rock_per_player=20)

print("[ Paramètres ]")
print("  - nombre de pierres pour les deux joueur : ", rocks_per_players)
print("  - nombre de cases : ", grid_size)
print("  - position du troll : ", grid_size//2)

print("[Résultats]")
initial_status = Status(20, 20, grid_size // 2)
resultat_initial = prudent_strategy.get_gain_or_variables_values(initial_status)
print("Gain du joueur 1 pour l'état (", 20, ",", 20, ", 0) = ",
      resultat_initial[-1])
print("Stratégie du joueur 1 pour l'état (", 20, ",", 20, ", 0) = ",
      [round(i, 3) for i in resultat_initial[:-1]])

# QUESTION 4
print("[ QUESTION 4 ]")

max_rocks_for_player_2 = 100


''' Etude du cas générale '''
print("=====================================================")
print("                ETUDE DU CAS GENERALE                ")
print("=====================================================")
print("Initialisation de la stratégie prudente et de ses gains ...")
prudent_strategy = Question4PrudentStrategy(player=1, rock_per_player=20)

print("[ Paramètres ]")
print("  - nombre de pierres pour les deux joueur : ", rocks_per_players)
print("  - nombre de cases : ", grid_size)
print("  - position du troll : ", grid_size//2)

print("[Résultats]")
initial_status = Status(20, 20, grid_size // 2)
resultat_initial = prudent_strategy.get_gain_or_variables_values(initial_status)
print("Gain du joueur 1 pour l'état (", 20, ",", 20, ", 0) = ",
      resultat_initial[-1])
print("Stratégie du joueur 1 pour l'état (", 20, ",", 20, ", 0) = ",
      [round(i, 3) for i in resultat_initial[:-1]])

player_1_rocks = 20
player_2_rocks = 19
found = False
print("Galcule de l'état dans lequel le joueur 2 est avantagé ... ")
while player_2_rocks <= max_rocks_for_player_2:
    rock_per_player = max(player_2_rocks, player_1_rocks)
    prudent_strategy = Question4PrudentStrategy(player=1, rock_per_player=rock_per_player)
    status = Status(player_1_rocks, player_2_rocks, grid_size // 2)
    gain = prudent_strategy.get_float_gain(status)
    if gain < 0:
        print("Le joueur 2 a le jeux à son avantage si et seulement si il commence avec un nombre de pierres >= ", player_2_rocks)
        print("Si le joueur 2 commence avec ", player_2_rocks, " pierres, le gain du joueur 1 vaut ", gain)
        found = True
        break
    player_2_rocks += 1
if not found:
    print("le joueur 2 n'est jamais avantagé dans la limite du nombre de pierres que nous pouvons observer (",
          max_rocks_for_player_2, ")")



''' Le joueur 2 ne fait que des lancers impaires '''
print("=====================================================")
print("    Le joueur 2 ne fait que des lancers impaires     ")
print("    fichier Question4/q_4_1_prud_strat.py            ")
print("=====================================================")
print("Initialisation de la stratégie prudente et de ses gains ...")
prudent_strategy = Question41PrudentStrategy(player=1, rock_per_player=20)

print("[ Paramètres ]")
print("  - nombre de pierres pour les deux joueur : ", rocks_per_players)
print("  - nombre de cases : ", grid_size)
print("  - position du troll : ", grid_size//2)

print("[Résultats]")
initial_status = Status(20, 20, grid_size // 2)
resultat_initial = prudent_strategy.get_gain_or_variables_values(initial_status)
print("Gain du joueur 1 pour l'état (", 20, ",", 20, ", 0) = ",
      resultat_initial[-1])
print("Stratégie du joueur 1 pour l'état (", 20, ",", 20, ", 0) = ",
      [round(i, 3) for i in resultat_initial[:-1]])

player_1_rocks = 20
player_2_rocks = 19
found = False
while player_2_rocks <= max_rocks_for_player_2:
    rock_per_player = max(player_2_rocks, player_1_rocks)
    prudent_strategy = Question41PrudentStrategy(player=1, rock_per_player=rock_per_player)
    status = Status(player_1_rocks, player_2_rocks, grid_size // 2)
    gain = prudent_strategy.get_float_gain(status)
    if gain < 0:
        print("Le joueur 2 a le jeux à son avantage si et seulement si il commence avec un nombre de pierres >= ", player_2_rocks)
        print("Si le joueur 2 commence avec ", player_2_rocks, " pierres, le gain du joueur 1 vaut ", gain)
        found = True
        break
    player_2_rocks += 1
if not found:
    print("le joueur 2 n'est jamais avantagé dans la limite du nombre de pierres que nous pouvons observer (",
          max_rocks_for_player_2, ")")

