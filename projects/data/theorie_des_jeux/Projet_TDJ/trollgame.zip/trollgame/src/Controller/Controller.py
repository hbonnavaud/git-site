from src.Settings.settings import *
from src.Model.ObjectClasses.game_evolution import GameEvolution
from src.Model.ObjectClasses.Strategie.abstract_strategy import Strategy


class Controller:
    def __init__(self, model):
        self.model = model

    def run(self):
        while not self.model.is_finished():
            self.turn()

    def turn(self):
        """ Play a turn """
        ''' Get players choices '''
        player_1_choice = self.model.get_choice_for_player(1)
        player_2_choice = self.model.get_choice_for_player(2)

        ''' Update their memories '''
        self.model.strategy_for_player(1).our_choices.append(player_1_choice)
        self.model.strategy_for_player(1).other_player_choices.append(player_2_choice)
        self.model.strategy_for_player(2).our_choices.append(player_2_choice)
        self.model.strategy_for_player(2).other_player_choices.append(player_1_choice)

        ''' Update model's current turn's result '''
        self.model.player_1_choose = player_1_choice
        self.model.player_2_choose = player_2_choice
        assert self.model.player_1_choose is not None and self.model.player_2_choose is not None

        ''' End the turn '''
        # Update game information
        if self.model.player_1_choose < self.model.player_2_choose:
            self.model.troll_position -= 1
        elif self.model.player_1_choose > self.model.player_2_choose:
            self.model.troll_position += 1
        self.model.player_1_rocks_left -= self.model.player_1_choose
        self.model.player_2_rocks_left -= self.model.player_2_choose

        ''' End of the game verification '''
        # If the troll killed a player
        if self.model.troll_position == 0:
            self.model.game_evolution = GameEvolution.PLAYER_2_WIN
        elif self.model.troll_position == grid_size - 1:
            self.model.game_evolution = GameEvolution.PLAYER_1_WIN
        # If a player haven't rocks left
        elif self.model.player_1_rocks_left == 0:
            self.model.troll_position -= self.model.player_2_rocks_left
            self.model.troll_moved_at_the_end = -self.model.player_2_rocks_left
            self.check_for_winner()
        elif self.model.player_2_rocks_left == 0:
            self.model.troll_position += self.model.player_1_rocks_left
            self.model.troll_moved_at_the_end = self.model.player_1_rocks_left
            self.check_for_winner()

        self.model.notify_turn_ends()

    def check_for_winner(self):
        if self.model.troll_position < grid_size // 2:
            self.model.game_evolution = GameEvolution.PLAYER_2_WIN
        elif self.model.troll_position > grid_size // 2:
            self.model.game_evolution = GameEvolution.PLAYER_1_WIN
        else:
            self.model.game_evolution = GameEvolution.DRAW

