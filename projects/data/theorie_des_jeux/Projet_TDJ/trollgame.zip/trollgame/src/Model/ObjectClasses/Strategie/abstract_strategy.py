import abc


class Strategy(abc.ABC):
    def __init__(self, player=1):
        assert isinstance(player, int)
        self.player = player
        self.our_choices = []  # Our choices memory that should be update by the controller
        self.other_player_choices = []  # An enemy choices memory that should be update by the controller

    @abc.abstractmethod
    def get_choice(self, status):
        pass

    def other_player(self):
        return 1 if self.player == 2 else 2
