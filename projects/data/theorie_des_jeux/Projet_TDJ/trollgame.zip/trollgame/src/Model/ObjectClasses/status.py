from src.Settings.settings import grid_size


class Status:
    def __init__(self, player_1_rocks, player_2_rocks, troll_position):
        assert isinstance(player_1_rocks, int)
        assert isinstance(player_2_rocks, int)
        assert isinstance(troll_position, int)
        self.player_1_rocks = player_1_rocks
        self.player_2_rocks = player_2_rocks
        self.troll_position = troll_position

    def __str__(self):
        return "(" + str(self.player_1_rocks) + ", " + str(self.player_2_rocks) + ", " + str(self.troll_position) + ")"

    def is_trivial(self):
        return self.troll_position <= 0 or self.troll_position >= grid_size - 1 \
               or self.player_1_rocks == 0 or self.player_2_rocks == 0

    def rocks_for_player(self, player_num):
        assert player_num in [1, 2]
        return self.player_1_rocks if player_num == 1 else self.player_2_rocks