from scipy.optimize import linprog

from src.Model.ObjectClasses.Strategie.abstract_strategy import Strategy
from src.Model.ObjectClasses.status import Status
from src.Settings.settings import rocks_per_players, grid_size
from src.Model.Model import Model
import random


class Question4PrudentStrategy(Strategy):
    """
    Be careful: this class has been modified for TP question 4. It's not the real prudent strategy.
    General behaviour:
        - Every gains are stored in a 3 dimensional matrix: self.gain[x][y][z] = gain of Status(x,y,z)
        - At initialisation time, gain[rock_per_player][rock_per_player][grid_size//2] which is the first state
        of the game is initialised and so every reachable states are initialised too.
        Then gains aren't calculate many time.
    """

    def __init__(self, player=1, rock_per_player=rocks_per_players):
        assert isinstance(player, int) and player in [1, 2]

        super().__init__(player)

        ''' Initialise player gains '''
        self.gains = []  # self.gains[x][y][z] = gain of player for Status(x, y, z)
        for x in range(rock_per_player + 1):
            self.gains.append([])
            for y in range(rock_per_player + 1):
                self.gains[x].append([])
                for t in range(grid_size):
                    self.gains[x][y].append(None)

        # Initialise the higher gain will recursively initialise every others.
        self.initialise_gain(Status(player_1_rocks=rock_per_player,
                                    player_2_rocks=rock_per_player,
                                    troll_position=grid_size // 2))

    def get_choice(self, status):
        assert isinstance(status, Status)
        """
        Calculate player strategy.
        :return: player choice according to a prudent strategy.
        """
        # if we have no choices
        if status.rocks_for_player(self.player) == 1:
            return 1

        if status.is_trivial():
            return 0
        strategies_probabilities = self.get_gain_or_variables_values(status)
        assert strategies_probabilities is not None
        assert isinstance(strategies_probabilities, list)

        random_float = random.random()
        strategy = 1
        prob_sum = 0
        for prob in strategies_probabilities:
            prob_sum += prob
            if random_float < prob_sum:
                # play strategy
                return strategy
            strategy += 1
        return 1  # If we don't found a strategy, play 1

    def set_gains(self, status, value):
        """ Store the gain 'value' in gain_matrix's status's position"""
        assert isinstance(status, Status)
        assert value is not None
        if isinstance(value, int):
            value = float(value)
        if isinstance(value, float):
            value = round(value, 2)
        if isinstance(value, list):
            value[-1] = round(value[-1], 2)
        self.gains[status.player_1_rocks][status.player_2_rocks][status.troll_position] = value

    def gain_is_known(self, status):
        return self.gains[status.player_1_rocks][status.player_2_rocks][status.troll_position] is not None

    def get_gain_or_variables_values(self, status):
        """ return the element in self.gains that match with the status parameter
            if there's no gain yet for this game status, initialise it.
            Can return a variables's value list (if a simplex should be solved for it) or a float.
        """
        assert isinstance(status, Status)
        if not self.gain_is_known(status):
            self.initialise_gain(status)
        res = self.gains[status.player_1_rocks][status.player_2_rocks][status.troll_position]
        assert res is not None
        return res

    def get_float_gain(self, status):
        """ Same as get_gain_or_variables_values but return only float. """
        assert isinstance(status, Status)
        gain = self.get_gain_or_variables_values(status)
        if isinstance(gain, list):
            return gain[-1]
        else:
            assert isinstance(gain, float)
            return gain

    def initialise_gain(self, status):
        """
        Evaluate player 1 gain in a game status.
        :param status: Game status to evaluate.
        :return: player 1 gain, -1 if he lose, 1 if he win, 0 in equality case.
        """
        assert isinstance(status, Status)
        assert not self.gain_is_known(status)
        ''' calculate and return result '''
        if status.is_trivial():
            if status.troll_position == 0:
                self.set_gains(status, 1 if self.player == 2 else -1)
            elif status.troll_position == grid_size - 1:
                self.set_gains(status, - 1 if self.player == 2 else 1)

            elif status.player_1_rocks == 0 or status.player_2_rocks == 0:
                new_troll_position = 0
                if status.player_1_rocks == 0:
                    new_troll_position = status.troll_position
                    new_troll_position -= status.player_2_rocks
                elif status.player_2_rocks == 0:
                    new_troll_position = status.troll_position
                    new_troll_position += status.player_1_rocks
                val = 0
                if new_troll_position > grid_size // 2:
                    val = 1 if self.player == 1 else -1
                elif new_troll_position < grid_size // 2:
                    val = -1 if self.player == 1 else 1
                self.set_gains(status, val)
            else:
                raise Exception("Unknown trivial status")
                # If status is trivial, then we should return a result before to be here. There's a failure
        else:
            ''' Calculate the gain recursively '''
            self.solve_simplex_and_set_gain(status)

    def solve_simplex_and_set_gain(self, status):
        assert isinstance(status, Status)
        assert not status.is_trivial()
        ''' NB: If the player 1 have x rock left, we don't want to play more than x + 1 one.
            Then we are going to solve a simplex on a matrix with size x * x+1 '''

        # build an available statuses gain matrix
        gain_matrix = []
        for other_player_choice in range(1, status.rocks_for_player(self.other_player()) + 1):
            row = []
            '''
            We don't want to play more rocks than status.rocks_for_player(self.other_player()) + 1.
            But he can't send more than status.rocks_for_player(self.other_player()).
            The range of strategy we are going to look is 1 ... max(status.other_player_rocks + 1, status.our_rocks)+1
            '''
            for my_choice in range(1, min(status.rocks_for_player(self.player),
                                          status.rocks_for_player(self.other_player()) + 1)
                                      + 1):
                new_troll_position = status.troll_position
                if other_player_choice > my_choice:
                    new_troll_position -= 1 if self.player == 1 else -1
                elif my_choice > other_player_choice:
                    new_troll_position += 1 if self.player == 1 else - 1

                new_other_player_rocks_left = status.rocks_for_player(self.other_player()) - other_player_choice
                new_my_rocks_left = status.rocks_for_player(self.player) - my_choice
                if self.player == 1:
                    new_status = Status(new_my_rocks_left, new_other_player_rocks_left, new_troll_position)
                else:
                    new_status = Status(new_other_player_rocks_left, new_my_rocks_left, new_troll_position)
                assert 0 <= new_other_player_rocks_left < status.rocks_for_player(self.other_player())
                assert 0 <= new_my_rocks_left < status.rocks_for_player(self.player)
                assert 0 <= new_troll_position <= grid_size - 1
                row.append(self.get_float_gain(new_status))
            gain_matrix.append(row)

        '''
        c is the list of factors for each variables in the equation we want to minimise.
        We want to maximise t (the last variable) so we need to minimise -t.
        Then c = [0, ..., 0, -1] because we don't want others variables in this equation
        '''
        # how many variables we have without t <=> how many strategy we can take
        # NB: We don't want to play more rocks than the player 1 can do:
        # useless for player 2 to play 4 rocks if player 1 have only 2 rocks
        variables_size = min(status.rocks_for_player(self.player),
                             status.rocks_for_player(self.other_player()) + 1)
        c = []
        for _ in range(variables_size):
            c.append(0)
        c.append(-1)  # append factor for variable t

        '''
        We have constraints like a1*x1 + ... an * xn >= t with a1, ..., an are variable's factor and x1, ..., xn are the
        variables, and we need for each one a list a1, ..., an for a constraint that looks like 
        a1*x1 + ... an * xn <= k where k is a constant.

        reduce our constraint: a1*x1 + ... + an * xn >= t
                            => - a1*x1 - ... - an * xn <= - t
                            => - a1*x1 - ... - an * xn + t <= 0
        A is the list of constraint's left part.
        NB: each gain matrix row is a constraint
        '''
        A = []
        for row in gain_matrix:
            constraint_factors = []
            for fact in row:
                constraint_factors.append(-fact)
            constraint_factors.append(1)  # variable t factor
            A.append(constraint_factors)

        '''
        b is the list of constraint's right parts.
        Then b elements are constants but ARE NOT FACTORS.
        So b looks like: [0, ..., 0]
        '''
        b = []
        for _ in A:
            b.append(0)

        '''
        a_eq and b_eq works like A and b but as an equality constraint list.
        we want x1 + x2 + ... + xn = 1, but no t inside this constraint.
        So a_eq looks like [[1, 1, ..., 1, 0]] and b_eq = [1]
        '''
        a_eq = [[]]
        for _ in range(variables_size):
            a_eq[0].append(1)
        a_eq[0].append(0)
        b_eq = [1]

        '''
        bounds is the set of variable's bounds. Each bounds are like (0, None) without the one for variable t that
        looks like (None, None) because this variable isn't bounded.
        '''
        bounds = ()
        for _ in range(variables_size):
            bounds += ((0, None),)  # This is the way to append set into other set without concatenate them ...
        bounds += ((None, None),)  # After it it looks like bounds = ((0, None), ..., (0, None), (None, None))

        ''' Now we have every informations we need, solve the simplex ... '''
        res = linprog(c, A_ub=A, b_ub=b, A_eq=a_eq, b_eq=b_eq, bounds=bounds, method='revised simplex')
        # the list of variables value we are looking for is in res.x:
        self.set_gains(status, list(res.x))

    def __str__(self):
        return "Prudent strategy "


