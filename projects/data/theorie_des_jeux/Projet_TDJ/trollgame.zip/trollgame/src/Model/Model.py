from src.Model.Observable import Observable
from src.Settings.settings import *
from src.Model.ObjectClasses.game_evolution import GameEvolution
from src.Model.ObjectClasses.Strategie.abstract_strategy import Strategy
from src.Model.ObjectClasses.status import Status


class Model(Observable):

    def __init__(self, view, player_1_strategy=None, player_2_strategy=None):
        # None strategy mean human player.
        assert player_1_strategy is None or isinstance(player_1_strategy, Strategy)
        assert player_2_strategy is None or isinstance(player_2_strategy, Strategy)
        self.view = view

        self.troll_position = grid_size // 2  # troll position on the grid

        self.player_1_rocks_left = rocks_per_players  # rocks left for player 1
        self.player_2_rocks_left = rocks_per_players  # rocks left for player 2

        self.player_1_choose = None  # player 1 choice at time t-1
        self.player_2_choose = None  # player 2 choice at time t-1
        self.game_evolution = GameEvolution.NOT_FINISHED  # game status
        self.troll_moved_at_the_end = 0  # How many positions the troll moved when the game left
        self.player_1_strategy = player_1_strategy
        self.player_2_strategy = player_2_strategy

    def notify_turn_ends(self):
        self.view.update()

    def current_status(self):
        return Status(self.player_1_rocks_left, self.player_2_rocks_left, self.troll_position)

    def is_finished(self):
        return self.game_evolution != GameEvolution.NOT_FINISHED

    ''' Getters with player choice, useful for strategies'''
    def rocks_left_for_player(self, player_num):
        assert player_num in [1, 2]
        return self.player_1_rocks_left if player_num == 1 else self.player_2_rocks_left

    def current_choice_for_player(self, player_num):
        # A strategy have no reason to access current choice
        raise Exception("Access forbidden")

    def last_choice_for_player(self, player_num):
        assert player_num in [1, 2]
        return self.player_1_choose if player_num == 1 else self.player_2_choose

    def strategy_for_player(self, player_num):
        assert isinstance(player_num, int)
        return self.player_1_strategy if player_num == 1 else self.player_2_strategy

    def get_choice_for_player(self, player_num):
        assert isinstance(player_num, int)
        if self.strategy_for_player(player_num) is None:
            print("getting choice for None strategy")
            choice = self.view.get_user_choice()
        else:
            strategy = self.strategy_for_player(player_num)
            choice = strategy.get_choice(self.current_status())
        return choice
