import abc


class Observable(abc.ABC):

    @abc.abstractmethod
    def notify_turn_ends(self):
        pass
