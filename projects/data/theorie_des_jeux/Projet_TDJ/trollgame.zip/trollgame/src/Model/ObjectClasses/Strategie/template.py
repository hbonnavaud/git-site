from src.Model.ObjectClasses.Strategie.abstract_strategy import Strategy


class mystrategy(Strategy):
    def __init__(self, player=1):
        assert player in [1, 2]
        super().__init__(player)

    def get_choice(self, status):
        pass