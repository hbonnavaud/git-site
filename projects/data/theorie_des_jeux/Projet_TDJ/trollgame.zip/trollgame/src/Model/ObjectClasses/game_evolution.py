from enum import Enum


class GameEvolution(Enum):
    NOT_FINISHED = None
    DRAW = 0
    PLAYER_1_WIN = 1
    PLAYER_2_WIN = -1

    def __str__(self):
        return self.name
