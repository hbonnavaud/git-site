import numpy
from src.Model.ObjectClasses.Strategie.abstract_strategy import Strategy


class ExponentialStrategy(Strategy):
    """
    This strategy play a number of rocks that follow an exponential law of parameter lambda=1
    Exponential law return a value >= 0, and closer a value is from 0, the must it have probability to be choose.
    Simulation : https://homepage.divms.uiowa.edu/~mbognar/applets/exp-like.html
    Use lambda = 1

    """
    def __init__(self, player=1, value=1):
        """
        :param player: The player that will play this strategy
        :param lamb: lambda parameter for the exponential law
        """
        assert player in [1, 2]
        super().__init__(player)
        self.lamb = value
        if isinstance(value, int):
            self.lamb = float(value)
        assert isinstance(self.lamb, float)

    def get_choice(self, status):
        # Get a float value that follow an exponential law with lambda = 1
        # try it on simulator : https://homepage.divms.uiowa.edu/~mbognar/applets/exp-like.html
        rough_choice = numpy.random.exponential(scale=self.lamb, size=None)
        casted_choics = int(rough_choice) + 1  # we add 1 because result can be between 0 and 1
        if casted_choics <= status.rocks_for_player(self.player):
            assert casted_choics is not None
            return casted_choics
        else:
            assert status.rocks_for_player(self.player) is not None
            return status.rocks_for_player(self.player)

    def __str__(self):
        return "Exponential strategy with lambda " + str(self.lamb)
