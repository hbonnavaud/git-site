from src.Model.ObjectClasses.Strategie.abstract_strategy import Strategy


class TitForTatStrategy(Strategy):
    """
    This strategy play 1 at the first turn, and then play what the other player played before
    """
    def __init__(self, player=1):
        assert player in [1, 2]
        super().__init__(player)

    def get_choice(self, status):
        if len(self.other_player_choices) == 0:
            return 1
        elif self.other_player_choices[-1] <= status.rocks_for_player(self.player):
            return self.other_player_choices[-1]
        else:  # play everything left
            return status.rocks_for_player(self.player)

    def __str__(self):
        return "Tit for tat strategy "
