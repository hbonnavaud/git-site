from src.Model.ObjectClasses.Strategie.abstract_strategy import Strategy


class ConstantStrategy(Strategy):
    def __init__(self, player=1, value=2):
        assert player in [1, 2]
        super().__init__(player)
        self.value = value

    def get_choice(self, status):
        if status.rocks_for_player(self.player) < self.value:
            assert status.rocks_for_player(self.player) is not None
            return status.rocks_for_player(self.player)
        assert self.value is not None
        return self.value

    def __str__(self):
        return "Constant strategy with value " + str(self.value)
