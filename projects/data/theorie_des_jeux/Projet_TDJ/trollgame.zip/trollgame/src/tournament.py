from src.Model.ObjectClasses.Strategie.prudent_strategy import PrudentStrategy
from src.Model.ObjectClasses.Strategie.exponential_strategy import ExponentialStrategy
from src.Model.ObjectClasses.Strategie.tit_for_tat_strategy import TitForTatStrategy
from src.Model.ObjectClasses.Strategie.constant_strategy import ConstantStrategy
from src.Model.ObjectClasses.Strategie.abstract_strategy import Strategy
from src.View.tournament_view import TournamentMatchBuilder


def get_result(first_candidate, second_candidate2):
    global games_per_match

    assert isinstance(first_candidate, Strategy)
    assert isinstance(second_candidate2, Strategy)
    match = TournamentMatchBuilder(first_candidate, second_candidate2, games_per_match)
    res = match.get_result()
    return res


print("Loading strategies ...")

candidates_1 = []
candidates_2 = []
# Prudent strategy
candidates_1.append(PrudentStrategy(player=1))
candidates_2.append(PrudentStrategy(player=2))
# ExponentialStrategy with value 1
candidates_1.append(ExponentialStrategy(player=1, value=1))
candidates_2.append(ExponentialStrategy(player=2, value=1))
# ExponentialStrategy with value 1.5
candidates_1.append(ExponentialStrategy(player=1, value=1.5))
candidates_2.append(ExponentialStrategy(player=2, value=1.5))
# TitForTatStrategy
candidates_1.append(TitForTatStrategy(player=1))
candidates_2.append(TitForTatStrategy(player=2))
# ConstantStrategy with value 2
candidates_1.append(ConstantStrategy(player=1, value=2))
candidates_2.append(ConstantStrategy(player=2, value=2))
# ConstantStrategy with value 5
candidates_1.append(ConstantStrategy(player=1, value=5))
candidates_2.append(ConstantStrategy(player=2, value=5))

games_per_match = 10000

results = []
print("================================================================")
print("   ===      Welcome to the bit troll game tournament      ===   ")
print("================================================================")
print("Tournament initialisation ...")

''' Set tournament rules '''
print("Take a look at these rules : ")
print("  - Games per match: ", games_per_match)
print("\n")
print(" And here are our candidates !! ")
for candidate in candidates_1:
    print("  - ", candidate)
print("\n")

''' We want to make a game between each candidates '''
candidate_1_id = 0
candidate_2_id = 0
for candidate_1 in candidates_1:
    results.append([])
    for candidate_2 in candidates_2:
        result = get_result(candidate_1, candidate_2)
        results[candidate_1_id].append(result)
        candidate_2_id += 1
    candidate_1_id += 1

print("Tournament is done ! Here are the results:")

print("  - Players 1 candidates : ")
for index in range(1, len(candidates_1) + 1):
    print("      - ", str(index), ": ", str(candidates_1[index - 1]))

print("  - Players 2 candidates : ")
for index in range(1, len(candidates_2) + 1):
    print("      - ", str(index), ": ", str(candidates_2[index - 1]))


print("\n In this matrix you can find player 1 gain value.")
print("\n Players 1 id are in the left column, and player 2 id are in the first line")

print("         ", [" " + str(i) + "  " for i in range(1, len(candidates_2) + 1)])
print("         _____________________________________________________")
for index in range(1, len(candidates_1) + 1):
    print("  - ", str(index), ": ", results[index - 1])
