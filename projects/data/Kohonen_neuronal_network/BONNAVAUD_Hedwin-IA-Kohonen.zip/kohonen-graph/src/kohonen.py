# coding: utf8
# !/usr/bin/env python
# ------------------------------------------------------------------------
# Carte de Kohonen
# Écrit par Mathieu Lefort
#
# Distribué sous licence BSD.
# ------------------------------------------------------------------------
# Implémentation de l'algorithme des cartes auto-organisatrices de Kohonen
# ------------------------------------------------------------------------
# Pour que les divisions soient toutes réelles (pas de division entière)
from __future__ import division

# Librairie de calcul matriciel
import numpy

# Librairie d'affichage
import matplotlib.pyplot as plt
from math import sqrt, exp


class Neuron:
    """ Classe représentant un neurone """

    def __init__(self, w, position_x, position_y):
        """
        :summary: neuron creation
        :param w: numpy array
        :param position_x: (int) position en x du neurone dans la carte
        :param position_y: (int) position en y du neurone dans la carte
        """

        # Weights initialization
        self.weights = w.flatten()

        # Position initialization
        self.position_x = position_x
        self.position_y = position_y

        # Output initialization
        self.y = 0.

    def compute(self, input):
        """
        Affecte à y la valeur de sortie du neurone (i.e. la distance entre son poids et l'entrée)
        :param x: entrée du neurone
        """
        # Calcule de la distance euclidienne entre les poids
        self.y = numpy.linalg.norm(input - self.weights)

    def learn(self, eta, sigma, winner_distance, input):
        """
        Modifie les poids selon la règle de Kohonen
        :param eta: (float) taux d'apprentissage
        :param sigma: (float) largeur du voisinage
        :param winner_distance: (int) distance au neurone gagnant
        :param input: (numpy array) entrée du neurone
        :return:
        """

        # Calcule de l'exponentielle
        exponential = exp(- winner_distance / (2 * (sigma**2)))

        # Calcul de la distance à l'entrée
        input_distance = input - self.weights  # type = numpy.array

        # Calcule du nouveau poid

        observed_neuron = [9, 9]
        self.weights[:] = self.weights + input_distance * (eta * exponential)  # type = numpy.array


class SOM:
    """ Classe implémentant une carte de Kohonen. """

    def __init__(self, inputsize, gridsize):
        """
        Création du réseau
        :param inputsize: (tuple) taille de l'entrée
        :param gridsize: (tuple) taille de la carte
        """

        # Initialisation de la taille de l'entrée
        self.inputsize = inputsize

        # Initialisation de la taille de la carte
        self.gridsize = gridsize

        # Création de la carte
        # Carte de neurones
        self.map = []

        # Carte des poids
        self.weightsmap = []

        # Carte des activités
        self.activitymap = []

        for posx in range(gridsize[0]):
            mline = []
            wmline = []
            amline = []
            for posy in range(gridsize[1]):
                neuron = Neuron(numpy.random.random(self.inputsize), posx, posy)
                mline.append(neuron)
                wmline.append(neuron.weights)
                amline.append(neuron.y)
            self.map.append(mline)
            self.weightsmap.append(wmline)
            self.activitymap.append(amline)
        self.activitymap = numpy.array(self.activitymap)

    def compute(self, x):
        """
        Calcule de l'activité des neurones de la carte
        :param x: (numpy array) entrée de la carte (identique pour chaque neurone)
        :return:
        """

        # On demande à chaque neurone de calculer son activité et on met à jour la carte d'activité de la carte
        for posx in range(self.gridsize[0]):
            for posy in range(self.gridsize[1]):
                self.map[posx][posy].compute(x)
                self.activitymap[posx][posy] = self.map[posx][posy].y

    def learn(self, eta, sigma, x):
        """
        Modifie les poids de la carte selon la règle de Kohonen
        :param eta: (float) taux d'apprentissage
        :param sigma: (float) largeur du voisinage
        :param x: (numpy array) entrée de la carte
        :return:
        """

        # Calcul du neurone vainqueur
        bmux, bmuy = numpy.unravel_index(numpy.argmin(self.activitymap), self.gridsize)

        # Mise à jour des poids de chaque neurone
        for posx in range(self.gridsize[0]):
            for posy in range(self.gridsize[1]):
                distance = self.distance(posx, posy, bmux, bmuy)
                self.map[posx][posy].learn(eta, sigma, distance, x)

    def scatter_plot(self, interactive=False):
        """
        Affichage du réseau dans l'espace d'entrée (utilisable dans le cas d'entrée à deux dimensions et d'une
        carte avec une topologie de grille carrée)
        :param interactive: (boolean) Indique si l'affichage se fait en mode interactif
        :return:
        """

        # Création de la figure
        if not interactive:
            plt.figure()

        # Récupération des poids
        w = numpy.array(self.weightsmap)

        # Affichage des poids
        plt.scatter(w[:, :, 0].flatten(), w[:, :, 1].flatten(), c='k')

        # Affichage de la grille
        for i in range(w.shape[0]):
            plt.plot(w[i, :, 0], w[i, :, 1], 'k', linewidth=1.)
        for i in range(w.shape[1]):
            plt.plot(w[:, i, 0], w[:, i, 1], 'k', linewidth=1.)

        # Modification des limites de l'affichage
        plt.xlim(-1, 1)
        plt.ylim(-1, 1)

        # Affichage du titre de la figure
        plt.suptitle('Poids dans l\'espace d\'entree')

        # Affichage de la figure
        if not interactive:
            plt.show()

    def scatter_plot_2(self, interactive=False):
        """
        Affichage du réseau dans l'espace d'entrée en 2 fois 2d (utilisable dans le cas d'entrée à quatre dimensions
        et d'une carte avec une topologie de grille carrée)
        :param interactive: (boolean) Indique si l'affichage se fait en mode interactif
        """

        # Création de la figure
        if not interactive:
            plt.figure()

        # Affichage des 2 premières dimensions dans le plan
        plt.subplot(1, 2, 1)

        # Récupération des poids
        w = numpy.array(self.weightsmap)

        # Affichage des poids
        plt.scatter(w[:, :, 0].flatten(), w[:, :, 1].flatten(), c='k')

        # Affichage de la grille
        for i in range(w.shape[0]):
            plt.plot(w[i, :, 0], w[i, :, 1], 'k', linewidth=1.)
        for i in range(w.shape[1]):
            plt.plot(w[:, i, 0], w[:, i, 1], 'k', linewidth=1.)

        # Affichage des 2 dernières dimensions dans le plan
        plt.subplot(1, 2, 2)

        # Récupération des poids
        w = numpy.array(self.weightsmap)

        # Affichage des poids
        plt.scatter(w[:, :, 2].flatten(), w[:, :, 3].flatten(), c='k')

        # Affichage de la grille
        for i in range(w.shape[0]):
            plt.plot(w[i, :, 2], w[i, :, 3], 'k', linewidth=1.)
        for i in range(w.shape[1]):
            plt.plot(w[:, i, 2], w[:, i, 3], 'k', linewidth=1.)

        # Affichage du titre de la figure
        plt.suptitle('Poids dans l\'espace d\'entree')

        # Affichage de la figure
        if not interactive:
            plt.show()

    def plot(self):
        """
        Affichage des poids du réseau (matrice des poids)
        :return:
        """

        # Récupération des poids
        w = numpy.array(self.weightsmap)

        # Création de la figure
        f, a = plt.subplots(w.shape[0], w.shape[1])

        # Affichage des poids dans un sous graphique (suivant sa position de la SOM)
        for i in range(w.shape[0]):
            for j in range(w.shape[1]):
                plt.subplot(w.shape[0], w.shape[1], i * w.shape[1] + j + 1)
                im = plt.imshow(w[i, j].reshape(self.inputsize), interpolation='nearest', vmin=numpy.min(w),
                                vmax=numpy.max(w), cmap='binary')
                plt.xticks([])
                plt.yticks([])

        # Affichage de l'échelle
        f.subplots_adjust(right=0.8)
        cbar_ax = f.add_axes([0.85, 0.15, 0.05, 0.7])
        f.colorbar(im, cax=cbar_ax)

        # Affichage du titre de la figure
        plt.suptitle('Poids dans l\'espace de la carte')

        # Affichage de la figure
        plt.show()

    def MSE(self, X):
        """
        Calcul de l'erreur de quantification vectorielle moyenne du réseau sur le jeu de données
        :param X: (numpy array) le jeu de données
        :return:
        """

        # On récupère le nombre d'exemples
        nsamples = X.shape[0]

        # Somme des erreurs quadratiques
        s = 0

        # Pour tous les exemples du jeu de test
        for x in X:
            # On calcule la distance à chaque poids de neurone
            self.compute(x.flatten())
            # On rajoute la distance minimale au carré à la somme
            s += numpy.min(self.activitymap) ** 2

        # On renvoie l'erreur de quantification vectorielle moyenne
        return s / nsamples

    def distance(self, x1, y1, x2, y2):
        """
        return the distance between two neurons coordinates
        """
        winner_distance_x = abs(x1 - x2)
        winner_distance_y = abs(y1 - y2)
        return winner_distance_x ** 2 + winner_distance_y ** 2


    def AO(self):
        """
        Mesure de l'auto-organisation du réseau
        :return: le résultat ...
        """

        already_observed = []
        sum = 0
        size = 0
        for i1 in range(len(self.map)):
            for j1 in range(len(self.map[i1])):
                already_observed.append(self.map[i1][j1])
                for i2 in range(i1, len(self.map)):
                    for j2 in range(j1, len(self.map[i2])):
                        if self.map[i2][j2] not in already_observed:
                            size += 1
                            # Distance dans le plan
                            plan_distance_x = self.map[i1][j1].weights[0] - self.map[i2][j2].weights[0]
                            plan_distance_y = self.map[i1][j1].weights[1] - self.map[i2][j2].weights[1]
                            plan_distance = plan_distance_x ** 2 + plan_distance_y ** 2
                            # Divisée par la distance dans le graphe
                            sum += plan_distance / self.distance(i1, j1, i2, j2)

        return sum / size
