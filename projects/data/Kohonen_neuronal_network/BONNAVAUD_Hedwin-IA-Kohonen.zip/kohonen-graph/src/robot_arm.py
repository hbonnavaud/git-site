from simulation import load_dataset, simulation
from math import pi

""" This file give functions to train a Kohonen's network on a robot's arm dataset """

class RobotArm:
    def __init__(self, l1, l2):
        assert l1 > 0
        assert l2 > 0
        if isinstance(l1, int):
            l1 = float(l1)
        if isinstance(l2, int):
            l2 = float(l2)
        assert isinstance(l1, float)
        assert isinstance(l2, float)
        """
        :param l1: arm's first part length 
        :param l2: arm's second part length
        """
        ''' Settings '''
        DATASET_SIZE = 999

        ''' Load the dataset '''

        print("Initialisation du bras robotique ... ")
        print("Initialisation du jeux de données ... ")
        dataset = load_dataset(dataset_id=1, dataset_size=DATASET_SIZE, robot_dataset=True, arm_dimensions=[l1, l2])

        ''' Train a network '''

        print("Entrainement du réseau de neurones ... ")
        result = simulation(eta=0.1, sigma=1.2, dataset=dataset, graph_dimension=(12, 12),
                                dataset_size=DATASET_SIZE, robot=True, verbose=False, result_size=1, iterations=20000)

        # Get the trained network
        self.network = result["network"]
        self.error = result["res"][-1]["EQVM"]
        self.l1 = l1
        self.l2 = l2

    def build_data(self, data_1, data_2, get_position):
        """
        Return a restored dataset using a part of it.
        :param data_1: (Type: float) first data
        :param data_2: (Type: float) second data
        :param get_position: (Type: Boolean) True if we want to return a hand's position using arm's angles,
        False if we want to return arm's position using hand's position.
        :return: (Type: [float, float]) The angle that leads to position (pos_x, pos_y) for the hand
        """

        ''' Found three closest neurons for pos_x, pos_y '''
        top_3 = []
        for neuron_line in self.network.map:
            for neuron in neuron_line:
                # For each neuron ...
                # Get it's distance from the targeted position
                if get_position:
                    # We want hand's position, so data_1 and data_2 are arm's angles
                    distance_x = neuron.weights[0] - data_1
                    distance_y = neuron.weights[1] - data_2
                else:
                    # We want arm's angles, so data_1 and data_2 are hand's positions
                    distance_x = neuron.weights[2] - data_1
                    distance_y = neuron.weights[3] - data_2
                distance = distance_x ** 2 + distance_y ** 2

                # Use this distance to know if it's in the top 3:
                if len(top_3) == 0:
                    top_3.append({"neuron": neuron, "distance": distance})
                else:
                    index = len(top_3)
                    for i in range(len(top_3)):
                        if top_3[i]["distance"] < distance:
                            index = i
                            break
                    if len(top_3) < 3 or index != 0:  # insert
                        top_3 = top_3[:index] + [{"neuron": neuron, "distance": distance}] + top_3[index:]
                    if len(top_3) > 3:
                        top_3 = top_3[-3:]

        ''' Now top_3 contain the 3 closest neurons, find their importance '''
        method = 1  # Which method to choose for neurons importance, 1 or 2
        if method == 1:
            total_distance = sum([elt["distance"] for elt in top_3])
            total_importance = 0
            for elt in top_3:
                importance = 1 - (elt["distance"] / total_distance)
                total_importance += importance
                elt.update([("importance", importance)])
        else:
            total_importance = 0
            for elt in top_3:
                importance = 1
                for other in top_3:
                    if other == elt:
                        continue
                    assert other["neuron"].position_x != elt["neuron"].position_x or other["neuron"].position_y != elt["neuron"].position_y
                    importance *= other["distance"] / elt["distance"]
                elt.update([("importance", importance)])
                total_importance += importance

        # now fit these importance in [0, 1], to have a sum of importance = 1 
        for elt in top_3:
            elt.update([("importance", elt["importance"] / total_importance)])

        ''' [TEST] asserts on importance values : '''

        total_importance = 0
        for elt in top_3:
            assert 0 <= elt["importance"] <= 1
            total_importance += elt["importance"]
        if total_importance < 0.95 or total_importance > 1.05:
            # raise Exeption("AssertionError: total importance should be close or equal to 1")
            print("WARNING: total_importance = ", total_importance)

        ''' Now get an weighted mean on these three neurons '''
        if get_position:
            data = [data_1, data_2, 0, 0]  # Data we are looking for
        else:
            data = [0, 0, data_1, data_2]
        for elt in top_3:
            if get_position:
                data[2] += elt["importance"] * elt["neuron"].weights[2]
                data[3] += elt["importance"] * elt["neuron"].weights[3]
            else:
                data[0] += elt["importance"] * elt["neuron"].weights[0]
                data[1] += elt["importance"] * elt["neuron"].weights[1]
        return data

    def get_path(self, angle_1, angle_2, angle_3, angle_4, length):
        """
        Renvois une liste de positions de la main pour un bras passant des angles (angle_1, angle_2) aux angles
        (angle_3, angle_4).
        :param angle_1: Valeur initiale pour le premier angle.
        :param angle_2: Valeur initiale pour le second angle.
        :param angle_3: Valeur de destination pour le premier angle.
        :param angle_4: Valeur de destination pour le second angle.
        :param length: Nombre de position dans la trajectoire résultat.
        :return: Liste de position de la main.
         - Result[0] = Position initiale de la main. Puis les positions sont dans l'ordre jusqu'à :
         - Result[length - 1] = Position finale de la main.
        """
        res = []
        angle_1_evolution = abs(angle_1 - angle_3) / length
        angle_2_evolution = abs(angle_2 - angle_4) / length
        res.append(self.build_data(angle_1, angle_2, True))
        for _ in range(length):
            angle_1 += angle_1_evolution
            angle_2 += angle_2_evolution
            res.append(self.build_data(angle_1, angle_2, True))
        return res
