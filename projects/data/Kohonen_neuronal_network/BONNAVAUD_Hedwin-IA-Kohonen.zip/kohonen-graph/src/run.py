# coding: utf8
# !/usr/bin/env python
# ------------------------------------------------------------------------
# Carte de Kohonen
# Écrit par Mathieu Lefort
#
# Distribué sous licence BSD.
# ------------------------------------------------------------------------
# Implémentation de l'algorithme des cartes auto-organisatrices de Kohonen
# ------------------------------------------------------------------------
# Pour que les divisions soient toutes réelles (pas de division entière)

import sys
from simulation import load_dataset, simulation
from math import pi, cos, sin, sqrt
from kohonen import SOM

""" Program constants """
DEBUG = True        # Will print every information if True

"""     PARAMETERS     """
''' Parameters initialisation '''
GRAPH_DIMENSIONS = (10, 10)
ETA = 0.1          # Taux d'apprentissage
SIGMA = 1.4         # Largeur du voisinage
N = 30000           # Nombre de pas de temps d'apprentissage
VERBOSE = True      # Affichage interactif de l'évolution du réseau
STEPS_SIZE = 1000   # Nombre de pas de temps avant rafraichissement de l'affichage
DATASET_SIZE = 999  # Taille du jeux de donées
ROBOT_DATASET = False
DATASET_ID = 1

''' Set parameters '''
index = 1
while index < len(sys.argv):
    arg = sys.argv[index]
    if arg == "-h":
        VERBOSE = False
    elif arg == "-d":
        try:
            new_dataset = int(sys.argv[index + 1])
        except:
            raise Exception("integer expected after -d option.")
        index += 1  # Don't iterate throw observed dataset id
        DATASET_ID = new_dataset
    elif arg == "-r":
        ROBOT_DATASET = True
    elif arg in ["-e", "-s"]:
        try:
            value = float(sys.argv[index + 1])
        except:
            raise Exception("float expected after " + arg + " option.")
        index += 1  # Don't iterate throw observed dataset id
        if arg == "-e":
            ETA = value
        elif arg == "-s":
            SIGMA = value
    elif arg == "-rect":
        try:
            x = int(sys.argv[index + 1])
            y = int(sys.argv[index + 2])

        except:
            raise Exception("two integer expected after -d option.")
        if x <= 0 or y <= 0:
            raise Exception("Graph dimensions should be greater than 0.")
        index += 2  # Don't iterate throw observed dimensions
        GRAPH_DIMENSIONS = (x, y)
    else:
        raise Exception("Unknown option: \"" + arg + "\"")
    index += 1

''' Settings verification '''
if DEBUG:
    print("\n   ===     SETTINGS     ===     ")
    print("    - Graph dimensions: ", GRAPH_DIMENSIONS)
    print("    - Eta (learning rate): ", ETA)
    print("    - Sigma (Learning neighbourhood size): ", SIGMA)
    print("    - Dataset size: ", DATASET_SIZE)
    print("    - Selected dataset: ", DATASET_ID)
    print("    - Robot dataset: ", ROBOT_DATASET)
    print("   ===     ========     ===     ")

''' Load dataset '''
dataset = load_dataset(dataset_size=DATASET_SIZE, dataset_id=DATASET_ID, robot_dataset=ROBOT_DATASET)

''' Run the simulation '''
simulation(eta=ETA, sigma=SIGMA, dataset=dataset, graph_dimension=GRAPH_DIMENSIONS, dataset_size=DATASET_SIZE,
           robot=ROBOT_DATASET, verbose=VERBOSE, iterations=N, steps_size=STEPS_SIZE)
