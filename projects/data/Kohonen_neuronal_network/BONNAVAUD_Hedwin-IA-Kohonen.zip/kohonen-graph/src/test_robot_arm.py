from math import cos, sin, pi
from robot_arm import RobotArm

""" create a robot arm neuronal network and test it """

def get_exact_hand_position(angle_1, l1, angle_2, l2):
    """
    Get robot arm's hand position according to robot arm's angle.
    :param angle_1: First angle.
    :param l1: First length
    :param angle_2: Second angle
    :param l2: Second length
    :return: Hand's position
    """
    return [cos(angle_1) * l1 + cos(angle_1 + angle_2) * l2, sin(angle_1) * l1 + sin(angle_1 + angle_2) * l2]

def find_position_error(data, l1, l2):
    """
    get the error between angle and position on given data.
    :param data: (Type: float list, len of 4) Data to observe
    :param l2: first arm part's length
    :param l1: second arm part's length
    :return: Error between angles and hand's position in given data
    """
    exact_position = get_exact_hand_position(data[0], l1, data[1], l2)
    return abs(exact_position[0] - data[2]) + abs(exact_position[1] - data[3])

# Create and train our network
print("try ", i)
robot_arm = RobotArm(l1=0.7, l2=0.3)

find_position_from_angles = [[pi, pi], [pi/2, pi/2], [0, pi], [pi, 0], [pi/3, pi/5], [pi, pi/2]]
find_angles_from_positions = [[-0.5, 0.2], [0, 0.8], [0, 0.6], [-0.5, 0.4], [0.5, 0.4], [0, 1]]
find_path_from_evolution = [[pi, pi, 0, 0], [pi/2, pi/2, pi/2, pi/2], [0, pi, pi, 0], [pi, 0, pi/2, pi/2],
                    [pi/3, pi/5, pi, pi], [pi, pi/2, pi/2, pi]]

errors = []
if find_position_from_angles:
    print("   ===   Testing to find position from angles   === ")
    for angles in find_position_from_angles:
        print("---------------------------------------------------------")
        print("   - Test: find position from angles ", round(180*(angles[0]/pi), 2), ", ", round(180*(angles[1]/pi), 2))
        res = robot_arm.build_data(angles[0], angles[1], True)
        print("       Prediction: ", 180*round(res[0]/pi, 3), ", ", 180*round(res[1]/pi, 3), ", ", round(res[2], 3), ", ", round(res[3], 3))
        errors.append(find_position_error(res, robot_arm.l1, robot_arm.l2))
        print("       Found error = ", errors[-1])
    print("---------------------------------------------------------")

if find_angles_from_positions:
    print("   ===   Testing to find angles for positions   === ")
    for position in find_angles_from_positions:
        print("---------------------------------------------------------")
        print("   - Test: find angles from positions ", round(position[0], 2), ", ", round(position[1], 2))
        res = robot_arm.build_data(position[0], position[1], False)
        print("       Prediction: ", 180*round(res[0]/pi, 3), ", ", 180*round(res[1]/pi, 3), ", ", round(res[2], 3), ", ", round(res[3], 3))
        errors.append(find_position_error(res, robot_arm.l1, robot_arm.l2))
        print("       Found error = ", errors[-1])
    print("---------------------------------------------------------")

steps = 10  # How many steps inside the path
if find_path_from_evolution:
    for evolution in find_path_from_evolution:
        angle_1_evolution = (evolution[2] - evolution[0])/10
        angle_2_evolution = (evolution[3] - evolution[1])/10
        print("---------------------------------------------------------")
        print("   Angles goes from ", round(180*evolution[0]/pi, 2), "; ", round(180*evolution[1]/pi, 2), " to ",
              round(180*evolution[2]/pi, 2), "; ", round(180*evolution[3]/pi, 2))
        res = robot_arm.build_data(evolution[0], evolution[1], get_position=True)
        path = [res[-2:]]
        errors.append(find_position_error(res, robot_arm.l1, robot_arm.l2))
        for _ in range(steps):
            evolution[0] += angle_1_evolution
            evolution[1] += angle_2_evolution
            res = robot_arm.build_data(evolution[0], evolution[1], get_position=True)
            path.append(res[-2:])
            errors.append(find_position_error(res, robot_arm.l1, robot_arm.l2))

        print("   Path = ", [[round(val, 3) for val in pos] for pos in path])
        print("---------------------------------------------------------")
print("Average error = ", sum(errors) / len(errors))
