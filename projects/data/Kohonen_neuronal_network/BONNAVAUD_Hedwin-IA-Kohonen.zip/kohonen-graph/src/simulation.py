# coding: utf8
# !/usr/bin/env python
# ------------------------------------------------------------------------
# Carte de Kohonen
# Écrit par Mathieu Lefort
#
# Distribué sous licence BSD.
# ------------------------------------------------------------------------
# Implémentation de l'algorithme des cartes auto-organisatrices de Kohonen
# ------------------------------------------------------------------------
# Pour que les divisions soient toutes réelles (pas de division entière)

import sys
from enum import Enum

import matplotlib.pyplot as plt
import numpy
import random
from math import pi, cos, sin, sqrt
from kohonen import SOM

def load_dataset(dataset_size=999, dataset_id=1, robot_dataset=False, arm_dimensions=None):
    """
    Load and return the needed dataset.
    :param dataset_size: How many data in the result dataset
    :param dataset_id: Which dataset generator will be used
    :param robot_dataset: True if this is a robot arm dataset, false otherwise
    :param arm_dimensions: robot arm dimensions
    :return: A dataset that match arguments.
    """
    if arm_dimensions is None:
        arm_dimensions = [0.7, 0.3]
    if robot_dataset:
        if dataset_id == 1:
            # DATASET 1
            samples = numpy.random.random((dataset_size,4,1))
            samples[:,0:2,:] *= numpy.pi
            l1 = arm_dimensions[0]
            l2 = arm_dimensions[1]
            samples[:,2,:] = l1*numpy.cos(samples[:,0,:])+l2*numpy.cos(samples[:,0,:]+samples[:,1,:])
            samples[:,3,:] = l1*numpy.sin(samples[:,0,:])+l2*numpy.sin(samples[:,0,:]+samples[:,1,:])
            return samples
        else:
            # dataset_id is unknown, return first as default
            return load_dataset(dataset_size, 1, robot_dataset, arm_dimensions)
    else:
        if dataset_id == 1:
            # DATASET 1
            samples = numpy.random.random((dataset_size, 2, 1))
            samples[:, 0, :] -= 1
            return samples
        elif dataset_id == 2:
            # DATASET 2
            if dataset_size % 3 != 0:
                dataset_size += 3 - dataset_size % 3
            samples1 = -numpy.random.random((dataset_size // 3, 2, 1))
            samples2 = numpy.random.random((dataset_size // 3, 2, 1))
            samples2[:, 0, :] -= 1
            samples3 = numpy.random.random((dataset_size // 3, 2, 1))
            samples3[:, 1, :] -= 1
            return numpy.concatenate((samples1, samples2, samples3))
        elif dataset_id == 3:
            # DATASET 3
            if dataset_size % 2 == 1:
                dataset_size += 1
            samples1 = numpy.random.random((dataset_size//2, 2, 1))
            samples1[:, 0, :] -= 1
            samples2 = numpy.random.random((dataset_size//2, 2, 1))
            samples2[:, 1, :] -= 1
            return numpy.concatenate((samples1, samples2))
        elif dataset_id == 4:  # CERCLE
            # Jeux de données formant un cercle de rayon 0.75, et de centre (0.0)
            # Génération: à chaque étape, on tire un angle pour la nouvelle entrée.

            # On récupère des angles aléatoires entre 0 et 2*pi
            angles = [random.random() * 2 * pi for _ in range(dataset_size)]

            # Pour chacun de ces angles, on récupère sa position en x et y, tel que le cercle soit centré en (0, 0)
            # avec un rayon de 0.75
            coords = []
            for angle in angles:
                coords.append([[0.75 * cos(angle)], [0.75 * sin(angle)]])

            # On construit notre ensemble de données à partir de ces positions :
            return numpy.array(coords)
        elif dataset_id == 5:  # LIGNE HORIZONTALE
            # Jeux de données formant une ligne horizontale allant de -0.75 à + 0.75 en x et 0 en y
            # Génération: à chaque étape, on tire une abscisse pour la nouvelle entrée.

            # On récupère des abscisses aléatoires entre -0.75 et 0.75
            abscissa = [random.random() * 1.5 - 0.75 for _ in range(dataset_size)]

            # Pour chacun de ces angles, on récupère sa position en x et y, tel que le cercle soit centré en (0, 0)
            # avec un rayon de 0.75
            coords = []
            for abs in abscissa:
                coords.append([[abs], [0]])

            # On construit notre ensemble de données à partir de ces positions :
            return numpy.array(coords)
        elif dataset_id == 6:  # LIGNE COURBE
            # Jeux de données formant une ligne courbe, un cercle coupé horizontalement.
            # Génération: Ideme que pour le cercle mais coupé puis déplacé

            # On récupère des angles aléatoires entre 0 et 2*pi
            angles = [random.random() * 2 * pi for _ in range(dataset_size)]

            # Pour chacun de ces angles, on récupère sa position en x et y, tel que le cercle soit centré en (0, 0)
            # avec un rayon de 0.75
            coords = []
            for angle in angles:
                if angle <= pi:  # Partie supérieure du cercle
                    coords.append([[(0.75 * cos(angle) - 0.75) * 2/3], [0.75 * sin(angle)]])
                else:  # Partie inférieure du cercle
                    coords.append([[(0.75 * cos(angle) + 0.75) * 2/3], [0.75 * sin(angle)]])

            # On construit notre ensemble de données à partir de ces positions :
            return numpy.array(coords)
        elif dataset_id == 7:  # Triangle équilatérale
            # Jeux de données formant un triangle équilatérale centrée en (0, 0)
            edges_length = 1.5

            # On génère les données dans un rectancle de taille edges_length/2 et de hauteur sqrt(3)/2*edges_length
            # (soit la moitié de la base * la hauteur)
            h = sqrt(3)/2*edges_length  # hauteur
            dataset = numpy.random.random((dataset_size, 2, 1))  # On initialise les données aléatoirement dans un carré
            dataset[:, 0, :] *= edges_length/2  # On redéfinis l'abscisse des données
            dataset[:, 1, :] *= h  # On redéfinis la hauteur des données

            # On décale à gauche de 0 toutes les donées supérieures à la diagonale du triangle,
            # On sait que la diagonale du triangle (celle qui passe par l'origine) suit la courbe d'une fonction affine.
            # A partir de là, il est simple de savoir quels points sont au dessus :
            for point in dataset:
                # Fonction affine passant par l'origine : y = a * x
                x = point[0][0]
                y = point[1][0]
                a = 2 * h / edges_length
                if y >= a * x:
                    # Le point est au-dessus de la diagonale, on retourne cette moitiée supérieure
                    point[1][0] = h - point[1][0]
                else:
                    # Si non, on le déplace de edges_length/2 vers la gauche
                    point[0][0] -= edges_length / 2

            # On centre la figure en ordonneé
            dataset[:, 1, :] -= h/2
            return dataset
        else:
            # dataset_id is unknown, return first as default
            return load_dataset(dataset_size, 1, False)


def simulation(eta=0.1, sigma=1.2, dataset=None, graph_dimension=(10, 10), dataset_size=999, robot=False, verbose=False,
               result_size=1, iterations=30000, steps_size=1000):
    """
    Simulate a Kohonen graph learning.
    :param eta: Learning rate
    :param sigma: Learning neighbourhood size
    :param dataset: Dataset to train on
    :param robot: True if it is a robot arm dataset
    :param dataset_size: How many data in the result dataset
    :param result_size: How many evaluations during the simulation
    :param iterations: Number of iterations.
    :return: Print the result and also the evolution if VERBOSE == True,
    :return: Return ad dictionary like: {"neurons": network, "AVQE": avqe}
             AVQE stands for: Average vectorial quantification error
    """
    res = []  # Result
    if dataset is None:
        dataset = load_dataset(dataset_size, 1, robot)

    if robot and verbose:
        # Affichage des données (pour l'ensemble robotique)
        plt.figure()
        plt.subplot(1, 2, 1)
        plt.scatter(dataset[:, 0, 0].flatten(), dataset[:, 1, 0].flatten(), c='k')
        plt.subplot(1, 2, 2)
        plt.scatter(dataset[:, 2, 0].flatten(), dataset[:, 3, 0].flatten(), c='k')
        plt.suptitle('Donnees apprentissage')
        plt.show()
    elif verbose:
        # Affichage des données (pour les ensembles 1, 2 et 3)
        plt.figure()
        plt.scatter(dataset[:, 0, 0], dataset[:, 1, 0])
        plt.xlim(-1, 1)
        plt.ylim(-1, 1)
        plt.suptitle('Donnees apprentissage')
        plt.show()

    if len(dataset) != dataset_size:
        raise Exception("Too few samples in array.")

    # Création d'un réseau avec une entrée (input_length, 1) et une carte (10,10)
    input_length = len(dataset[numpy.random.randint(dataset_size)].flatten())
    network = SOM((input_length, 1), graph_dimension)

    # SIMULATION
    # Affichage des poids du réseau
    if verbose:
        network.plot()

    # Initialisation de l'affichage interactif
    if verbose:
        # Création d'une figure
        plt.figure()

        # Mode interactif
        plt.ion()

        # Affichage de la figure
        plt.show()

    # Boucle d'apprentissage
    for i in range(iterations + 1):
        # Choix d'un exemple aléatoire pour l'entrée courante
        index = numpy.random.randint(dataset_size)
        x = dataset[index].flatten()

        # Calcul de l'activité du réseau
        network.compute(x)

        # Modification des poids du réseau
        network.learn(eta, sigma, x)

        # Mise à jour de l'affichage
        if verbose and i % steps_size == 0:
            # Effacement du contenu de la figure
            plt.clf()

            # Remplissage de la figure
            if robot:
                network.scatter_plot_2(True)
            else:
                network.scatter_plot(True)

            # Affichage du contenu de la figure
            plt.pause(0.00001)
            plt.draw()
        if i % (iterations // result_size) == 0:
            res.append({
                "EQVM": network.MSE(dataset),  # Erreur de Quantification Vectorielle Moyenne
                "AO": network.AO()  # Mesure d'auto-organisation (lâchetée du graphe)
            })

    # Fin de l'affichage interactif
    if verbose:
        # Désactivation du mode interactif
        plt.ioff()

        # Affichage des poids du réseau
        network.plot()

    # Affichage de l'erreur de quantification vectorielle moyenne après apprentissage
    print("erreur de quantification vectorielle moyenne ", network.MSE(dataset))
    return {"res": res, "network": network}
