# -*-coding:Latin-1 -*

from simulation import load_dataset, simulation


DATASET_SIZE = 999
datasets = [
    # {"data": load_dataset(dataset_size=DATASET_SIZE, dataset_id=1, robot_dataset=False), "name": "Carre"},
    {"data": load_dataset(dataset_size=DATASET_SIZE, dataset_id=1, robot_dataset=True), "name": "Robot"},
    # {"data": load_dataset(dataset_size=DATASET_SIZE, dataset_id=4, robot_dataset=False), "name": "Cercle"},
    # {"data": load_dataset(dataset_size=DATASET_SIZE, dataset_id=6, robot_dataset=False), "name": "Ligne courbe"},
    # {"data": load_dataset(dataset_size=DATASET_SIZE, dataset_id=7, robot_dataset=False), "name": "Triangle"}
]

# Which variables do you want to test ?
TEST_ETA = False
TEST_SIGMA = True
TEST_MAP_SIZE = False

Tests = {
    "Eta": [0.05, 0.1, 0.2, 0.4],
    "Sigma": [0.5, 1, 1.2, 1.5, 2., 3., 4.],
    "Carte": [(5, 5), (10, 10), (13, 13), (1, 10), (5, 10), (10, 15)]
}

# Default parameters:
ETA = 1
SIGMA = 1.2
GRAPH_DIMENSIONS = (10, 10)

iterations_per_simulation = 20000
evaluations_per_simulations = 100  # Nombre d'�valuations par simulations

for dataset in datasets:
    print("   ===   Tests for dataset ", dataset["name"], "  ===   ")
    tests_results = []
    if TEST_ETA:
        print("Testing Eta with values in ", Tests["Eta"])
        eta_results = []
        for value in Tests["Eta"]:
            res = simulation(eta=value, sigma=SIGMA, dataset=dataset["data"], graph_dimension=GRAPH_DIMENSIONS,
                             dataset_size=DATASET_SIZE, verbose=False, result_size=evaluations_per_simulations,
                             iterations=iterations_per_simulation)["res"]
            eta_results.append(res)
        tests_results.append(eta_results)

    if TEST_SIGMA:
        print("Testing Sigma with values in ", Tests["Sigma"])
        sigma_results = []
        for value in Tests["Sigma"]:
            res = simulation(eta=ETA, sigma=value, dataset=dataset["data"], graph_dimension=GRAPH_DIMENSIONS,
                             dataset_size=DATASET_SIZE, verbose=False, result_size=evaluations_per_simulations,
                             iterations=iterations_per_simulation)["res"]
            sigma_results.append(res)
        tests_results.append(sigma_results)

    if TEST_MAP_SIZE:
        map_size_results = []
        print("Testing map size with values in ", Tests["Carte"])
        for value in Tests["Carte"]:
            res = simulation(eta=ETA, sigma=SIGMA, dataset=dataset["data"], graph_dimension=value,
                             dataset_size=DATASET_SIZE, verbose=False, result_size=evaluations_per_simulations,
                             iterations=iterations_per_simulation)["res"]
            map_size_results.append(res)
        tests_results.append(map_size_results)

    for i in range(evaluations_per_simulations + 1):
        line = ""
        for test in tests_results:
            for value_test in test:
                line += str(round(value_test[i]["EQVM"], 3)) + " ; " + str(round(value_test[i]["AO"], 3)) + " || "
        print(line)

