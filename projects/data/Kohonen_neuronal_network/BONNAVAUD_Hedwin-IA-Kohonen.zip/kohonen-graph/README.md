# Projet de master sur les cartes de Kohonen

Par Hedwin BONNAVAUD

Enseignant : LEFORT Mathieu

## Description

Projet de cours ayant pour objectif, l'étude et la compréhension du 
fonctionnement d'une carte de kohonen.

## Utilisation

___

**Pour lancer une simulation**

`python3 src/run.py` lance une simulation simple.

**Options**

 - `-h` (hidden) désactive l'option verbose, supprime 
 l'affichage pour une simulation plus rapide.
 - `-r` pour lancer un jeux de données du bras robotique.
 - `-d <num>` lance la simulation sur le jeux de données numéro <num>.
 Si ce jeux de données n'est pas connus, utilise le jeux de données 1 par défaut.
 - `-rect x y` Pour préciser que le graph de neurones est un rectangle de taille x y.
 Par défaut, le graph de neurones est un rectangle de taille 10 par 10.

___

**Pour lancer les tests du bras robotique**

python3 src/test_robot_arm.py

## Résultats des tests

Accessible sur google sheet à l'addresse : 
https://docs.google.com/spreadsheets/d/1OXJgpJGL_rvd-0w1iNWzVmHlp3SPuzUfBoE1XZ-mdTg/edit?usp=sharing
 
